package entity;
import main.GamePanel;
import entity.Projectile;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Player  {
    BufferedImage rightlooking, leftlooking;
    String direction;
    int playerX;
    int playerY;
    int playerSpeed;
    public int maxHealth;
    public int health;

    double velocityY = 0;
    double gravity = 0.4;
    double jumpStrength = -10;
    boolean onGround = false;
    int playerNumber;

    Projectile projectile;
    GamePanel gamepanel;
    Controls controls;
    Rectangle hitbox;

    public Player(GamePanel gamepanel, Controls controls, int playerNumber) {
        this.gamepanel = gamepanel;
        this.controls = controls;
        this.playerNumber = playerNumber;
        setDefaultValues(playerNumber);
        getPlayerImage(playerNumber);
        hitbox = new Rectangle(0, 0, gamepanel.tileSize, gamepanel.tileSize);
    }

    public void setDefaultValues(int playerNumber) {

        playerSpeed = 5;

        if (playerNumber == 1) {
            playerX = 144;
            playerY = 347;
            direction = "right";
        }

        if (playerNumber == 2) {
            playerX = 1728;
            playerY = 347;
            direction = "left";
        }
    }

    public void getPlayerImage(int playerNumber) {
        try {
            rightlooking = ImageIO.read(getClass().getResourceAsStream("/sprites/player/p" + playerNumber + "Right.png"));
            leftlooking = ImageIO.read(getClass().getResourceAsStream("/sprites/player/p" + playerNumber + "Left.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void update() {

        // ================= HORIZONTALE BEWEGUNG =================
        if (controls.left()) {
            playerX -= playerSpeed;
            direction = "left";
        }
        if (controls.right()) {
            playerX += playerSpeed;
            direction = "right";
        }
        checkHorizontalCollision();

        // Springen
        if (controls.up() && onGround) {
            velocityY = jumpStrength;
            onGround = false;
        }

        if (controls.shot() && (projectile == null || !projectile.alive)) {
            projectile = new Projectile(gamepanel);
            projectile.getImage();
            projectile.set(playerX, playerY, direction, true);
            gamepanel.projectileList.add(projectile);
        }

        // Gravity
        velocityY += gravity;
        playerY += velocityY;

        checkVerticalCollision();

        // Screen Begrenzung
        if (playerX < 0) playerX = 0;
        if (playerX > gamepanel.screenWidth - gamepanel.tileSize)
            {playerX = gamepanel.screenWidth - gamepanel.tileSize;}
        if (playerY < 0) playerY = 0;
    }

    public void checkHorizontalCollision() {
        int leftCol = playerX / gamepanel.tileSize;
        int rightCol = (playerX + gamepanel.tileSize - 1) / gamepanel.tileSize;
        int topRow = playerY / gamepanel.tileSize;
        int bottomRow = (playerY + gamepanel.tileSize - 1) / gamepanel.tileSize;

        // anti-Crash
        leftCol = Math.max(0, leftCol);
        rightCol = Math.min(gamepanel.platformM.getCols() - 1, rightCol);
        topRow = Math.max(0, topRow);
        bottomRow = Math.min(gamepanel.platformM.getRows() - 1, bottomRow);

        // links laufi
        if (controls.left()) {
            boolean collisionTop = gamepanel.platformM.getPlatform(
                    gamepanel.platformM.getMapPlatformNum(leftCol, topRow)
            ).collision;
            boolean collisionBottom = gamepanel.platformM.getPlatform(
                    gamepanel.platformM.getMapPlatformNum(leftCol, bottomRow)
            ).collision;

            if (collisionTop || collisionBottom) {
                playerX = (leftCol + 1) * gamepanel.tileSize;
            }
        }

        // rechts laufi
        if (controls.right()) {
            boolean collisionTop = gamepanel.platformM.getPlatform(
                    gamepanel.platformM.getMapPlatformNum(rightCol, topRow)).collision;
            boolean collisionBottom = gamepanel.platformM.getPlatform(
                    gamepanel.platformM.getMapPlatformNum(rightCol, bottomRow)).collision;

            if (collisionTop || collisionBottom) {
                playerX = rightCol * gamepanel.tileSize - gamepanel.tileSize;
            }
        }
    }

    public void checkVerticalCollision() {
        int leftCol = playerX / gamepanel.tileSize;
        int rightCol = (playerX + gamepanel.tileSize - 1) / gamepanel.tileSize;
        int topRow = playerY / gamepanel.tileSize;
        int bottomRow = (playerY + gamepanel.tileSize - 1) / gamepanel.tileSize;

        // anti crashh
        leftCol = Math.max(0, leftCol);
        rightCol = Math.min(gamepanel.platformM.getCols() - 1, rightCol);
        topRow = Math.max(0, topRow);
        bottomRow = Math.min(gamepanel.platformM.getRows() - 1, bottomRow);

        onGround = false;

        // ===== FALLEN =====
        if (velocityY > 0) {
            boolean collisionLeft = gamepanel.platformM.getPlatform(
                    gamepanel.platformM.getMapPlatformNum(leftCol, bottomRow)).collision;
            boolean collisionRight = gamepanel.platformM.getPlatform(
                    gamepanel.platformM.getMapPlatformNum(rightCol, bottomRow)).collision;

            if (collisionLeft || collisionRight) {
                playerY = bottomRow * gamepanel.tileSize - gamepanel.tileSize;
                velocityY = 0;
                onGround = true;
            }
        }

        // gegen block springen von unten
        if (velocityY < 0) {
            boolean collisionLeft = gamepanel.platformM.getPlatform(
                    gamepanel.platformM.getMapPlatformNum(leftCol, topRow)).collision;
            boolean collisionRight = gamepanel.platformM.getPlatform(
                    gamepanel.platformM.getMapPlatformNum(rightCol, topRow)).collision;

            if (collisionLeft || collisionRight) {
                playerY = (topRow + 1) * gamepanel.tileSize;
                velocityY = 0;
            }
        }

        if (playerY + velocityY >= gamepanel.screenHeight - gamepanel.tileSize) {
            respawn();
        }
    }
    public void respawn() {
        velocityY = 0;
        onGround = false;
        setDefaultValues(playerNumber);
    }
    public void draw(Graphics2D g2) {
        BufferedImage image = direction.equals("right") ? rightlooking : leftlooking;
        g2.drawImage(image, playerX, playerY, gamepanel.tileSize, gamepanel.tileSize, null);
    }
}