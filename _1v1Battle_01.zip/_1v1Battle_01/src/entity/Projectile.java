package entity;

import main.GamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Projectile {

        GamePanel gp;
        Player owner;

        public Projectile(GamePanel gp, Player owner) {
                this.gp = gp;
                this.owner = owner;
        }

        BufferedImage rightlooking, leftlooking;
        String direction = "right";

        int projX;
        int projY;

        public boolean alive = false;

        int projSpeed = 10;

        Rectangle hitbox = new Rectangle();

        public void set(int projX, int projY, String direction, boolean alive) {
                this.projX = projX;
                this.projY = projY;
                this.direction = direction;
                this.alive = alive;
        }

        public void update() {

                switch (direction) {
                        case "right":
                                projX += projSpeed;
                                break;

                        case "left":
                                projX -= projSpeed;
                                break;
                }

                if (projX < 0 || projX > 1920) {
                        alive = false;
                }

                hitbox.x = projX;
                hitbox.y = projY + gp.tileSize - (gp.tileSize / 2);
                hitbox.width = 32;
                hitbox.height = 16;

                checkHorizontalCollision();
                checkPlayerCollision();
        }

        public void getImage() {
                try {
                        rightlooking = ImageIO.read(getClass().getResourceAsStream("/sprites/projectile/projectile_right.png"));
                        leftlooking = ImageIO.read(getClass().getResourceAsStream("/sprites/projectile/projectile_left.png"));
                } catch (IOException e) {
                        e.printStackTrace();
                }
        }

        public void draw(Graphics2D g2) {
                BufferedImage image = direction.equals("right") ? rightlooking : leftlooking;
                g2.drawImage(image, projX, projY + gp.tileSize - (gp.tileSize/2), 32, 16, null);
        }

        public void checkHorizontalCollision() {

                int leftCol = projX / gp.tileSize;
                int rightCol = (projX + gp.tileSize - 1) / gp.tileSize;
                int topRow = projY / gp.tileSize;
                int bottomRow = (projY + gp.tileSize - 1) / gp.tileSize;

                leftCol = Math.max(0, leftCol);
                rightCol = Math.min(gp.platformM.getCols() - 1, rightCol);
                topRow = Math.max(0, topRow);
                bottomRow = Math.min(gp.platformM.getRows() - 1, bottomRow);

                if (direction.equals("left")) {

                        boolean collisionTop = gp.platformM.getPlatform(
                                gp.platformM.getMapPlatformNum(leftCol, topRow)
                        ).collision;

                        boolean collisionBottom = gp.platformM.getPlatform(
                                gp.platformM.getMapPlatformNum(leftCol, bottomRow)
                        ).collision;

                        if (collisionTop || collisionBottom) {
                                alive = false;
                        }
                }

                if (direction.equals("right")) {

                        boolean collisionTop = gp.platformM.getPlatform(
                                gp.platformM.getMapPlatformNum(rightCol, topRow)).collision;

                        boolean collisionBottom = gp.platformM.getPlatform(
                                gp.platformM.getMapPlatformNum(rightCol, bottomRow)).collision;

                        if (collisionTop || collisionBottom) {
                                alive = false;
                        }
                }
        }

        public void checkPlayerCollision() {

                if(owner != gp.p1){

                        Rectangle p1Hitbox = new Rectangle(gp.p1.playerX, gp.p1.playerY, gp.tileSize, gp.tileSize);

                        if(hitbox.intersects(p1Hitbox)){

                                gp.p1.takeDamage();

                                if(direction.equals("right")){
                                        gp.p1.playerX += 50;
                                } else {
                                        gp.p1.playerX -= 50;
                                }

                                alive = false;
                        }
                }

                if(owner != gp.p2){

                        Rectangle p2Hitbox = new Rectangle(gp.p2.playerX, gp.p2.playerY, gp.tileSize, gp.tileSize);

                        if(hitbox.intersects(p2Hitbox)){

                                gp.p2.takeDamage();

                                if(direction.equals("right")){
                                        gp.p2.playerX += 50;
                                } else {
                                        gp.p2.playerX -= 50;
                                }

                                alive = false;
                        }
                }
        }
}