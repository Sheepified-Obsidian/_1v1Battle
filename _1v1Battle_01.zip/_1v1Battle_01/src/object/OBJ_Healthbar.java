package object;
import main.GamePanel;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import entity.Player;

public class OBJ_Healthbar extends SuperObject {

    GamePanel gp;
    BufferedImage image[] = new BufferedImage[12];
    Player owner;

    public OBJ_Healthbar(GamePanel gp, Player owner){
        this.gp = gp;
        this.owner = owner;
        name = "Healthbar";
        BufferedImage sheet;

        try{
            sheet = ImageIO.read(getClass().getResourceAsStream("/sprites/hearts/Health Bar.png"));
            for (int i = 0; i < 12; i++) {
                image[i] = sheet.getSubimage(i * frameSize, 0, frameSize, frameSize);
            }
        }
        catch (Exception e) {
            e.printStackTrace();

        }
    }

    @Override
    public void draw(Graphics2D g2, GamePanel gp){

        int startIndex;
        if (owner.health == 2) {
            startIndex = 0;
        } else if (owner.health == 1) {
            startIndex = 4;
        }
        else {
            startIndex = 8;
        }

        for (int i = 0; i < 4; i++) {

            int x;

            if(owner == gp.p1){
                x = 20 + i * gp.tileSize;  // links
            }
            else{
                x = gp.screenWidth - (4 * gp.tileSize) - 20 + i * gp.tileSize; // rechts
            }

            int y = worldY;
            g2.drawImage(image[startIndex + i], x, y, gp.tileSize, gp.tileSize, null);

        }
    }
}