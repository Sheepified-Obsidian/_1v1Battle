import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
public class Player extends Entity{

    private KeyHandler keyH;

    public Player(KeyHandler keyH) {
        this.keyH = keyH;
        x = 100;
        y = 100;
        speed = 4;
        direction = "right";

        getPlayerImage();
    }

    public void getPlayerImage(){
        try {

            right = ImageIO.read(getClass().getResourceAsStream("/player/FigurRight.png"));
            left = ImageIO.read(getClass().getResourceAsStream("/player/FigurLeft.png"));

        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void update() {
        if (keyH.upPressed == true){
            direction = "up";
            y -= speed;
        }
        if (keyH.downPressed == true){
            direction = "down";
            y += speed;
        }
        if (keyH.leftPressed == true){
            direction = "left";
            x -= speed;
        }
        if (keyH.rightPressed == true){
            direction = "right";
            x += speed;
        }
    }

    public void draw(Graphics2D g2) {

        BufferedImage image = null;

        if  ("right".equals(direction)) {
            image = right;
        }
        if ("left".equals(direction)) {
            image =left;
        }

        g2.drawImage(image, x,y,50,50, null);



    }
}
