package main;

import platform.PlatformManager;
import object.SuperObject;
import entity.Projectile;
import entity.Player;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class GamePanel extends JPanel implements Runnable {

    //Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    final int originalTileSize = 16;
    final int scale = 3;
    public final int tileSize = originalTileSize * scale;

    public final int screenWidth = 1920;
    public final int screenHeight = 1080;
    public final int maxScreenCol = screenWidth/tileSize;
    public final int maxScreenRow = screenHeight/tileSize;
    public ArrayList<Projectile> projectileList = new ArrayList<>();

    public PlatformManager platformM;

    KeyHandlerWASD keyHWASD = new KeyHandlerWASD();
    KeyHandlerArrows keyHArrows = new KeyHandlerArrows();

    public AssetSetter aSetter;
    public SuperObject obj[] = new SuperObject[10];

    public Player p1;
    public Player p2;

    Thread gameThread;

    public GamePanel() {

        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
        this.setFocusable(true);


        this.addKeyListener(keyHArrows);
        this.addKeyListener(keyHWASD);

        platformM = new PlatformManager(this);
        aSetter = new AssetSetter(this);

        p1 = new Player(this, keyHWASD, 1);
        p2 = new Player(this, keyHArrows, 2);
    }

    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void setupGame(){
        aSetter.setObject();
    }

    @Override
    public void run() {
        while (gameThread != null) {

            update();
            repaint();

            try {
                Thread.sleep(16);
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void update() {
        p1.update();
        p2.update();

        for(int i = 0; i < projectileList.size(); i++){
            if(projectileList.get(i) != null){
                if(projectileList.get(i).alive == true)
                    projectileList.get(i).update();

                if(projectileList.get(i).alive == false) {
                    projectileList.remove(i);
                }
            }
        }
    }

    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        platformM.draw(g2);

        p1.draw(g2);
        p2.draw(g2);

        for(int i = 0; i < obj.length; i++){
            if(obj[i] != null){
                obj[i].draw(g2,this);
            }
        }

        for(int i = 0; i < projectileList.size(); i++){
            if(projectileList.get(i) != null){
                projectileList.get(i).draw(g2);
            }
        }

        g2.dispose();
    }
}
