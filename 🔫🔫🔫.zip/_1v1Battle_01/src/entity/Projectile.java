package entity;
import main.GamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Projectile {
        GamePanel gp;
        public Projectile (GamePanel gp) {
                this.gp = gp;
        }

        BufferedImage rightlooking, leftlooking;
        String direction = "right";
        int projX;
        int projY;
        public boolean alive = false;
        int projSpeed = 10;
        int damage = 1;
        int ownerPlayerNumber;

        public void set(int projX, int projY, String direction, boolean alive, int ownerPlayerNumber) {
                this.projX = projX;
                this.projY = projY;
                this.direction = direction;
                this.alive = alive;
                this.ownerPlayerNumber = ownerPlayerNumber;
        }

        public void update() {
                switch (direction) {
                        case "right":
                                projX += projSpeed;
                                break;
                        case "left":
                                projX -= projSpeed;
                                break;
                }

                if (projX < 0 || projX > 1920) {
                        alive = false;
                }
                checkHorizontalCollision();
                checkPlayerCollision();
        }
        public void getImage() {
                try {
                        rightlooking = ImageIO.read(getClass().getResourceAsStream("/sprites/projectile/projectile_right.png"));
                        leftlooking = ImageIO.read(getClass().getResourceAsStream("/sprites/projectile/projectile_left.png"));
                } catch (IOException e) {
                        e.printStackTrace();
                }
        }

        public void draw(Graphics2D g2) {
                BufferedImage image = direction.equals("right") ? rightlooking : leftlooking;
                g2.drawImage(image, projX + gp.tileSize, projY, 32, 16, null);
        }

        public Rectangle getBounds() {
                return new Rectangle(projX + gp.tileSize, projY, 32, 16);
        }

        public void checkPlayerCollision() {
                if (!alive) {
                        return;
                }

                Player target = ownerPlayerNumber == 1 ? gp.p2 : gp.p1;
                if (target.waitingForRespawn) {
                        return;
                }

                Rectangle targetBounds = new Rectangle(target.playerX, target.playerY, gp.tileSize, gp.tileSize);
                if (getBounds().intersects(targetBounds)) {
                        for (int i = 0; i < damage; i++) {
                                target.takeDamage();
                        }
                        alive = false;
                }
        }

        public void checkHorizontalCollision() {
                int leftCol = projX / gp.tileSize;
                int rightCol = (projX + gp.tileSize - 1) / gp.tileSize;
                int topRow = projY / gp.tileSize;
                int bottomRow = (projY + gp.tileSize - 1) / gp.tileSize;

                leftCol = Math.max(0, leftCol);
                rightCol = Math.min(gp.platformM.getCols() - 1, rightCol);
                topRow = Math.max(0, topRow);
                bottomRow = Math.min(gp.platformM.getRows() - 1, bottomRow);

                if (direction.equals("left")) {
                        boolean collisionTop = gp.platformM.getPlatform(
                                gp.platformM.getMapPlatformNum(leftCol, topRow)
                        ).collision;
                        boolean collisionBottom = gp.platformM.getPlatform(
                                gp.platformM.getMapPlatformNum(leftCol, bottomRow)
                        ).collision;

                        if (collisionTop || collisionBottom) {
                                alive = false;
                        }
                }

                if (direction.equals("right")) {
                        boolean collisionTop = gp.platformM.getPlatform(
                                gp.platformM.getMapPlatformNum(rightCol, topRow)).collision;
                        boolean collisionBottom = gp.platformM.getPlatform(
                                gp.platformM.getMapPlatformNum(rightCol, bottomRow)).collision;

                        if (collisionTop || collisionBottom) {
                                alive = false;
                        }
                }

           }

}
