package entity;

public interface Controls {
        boolean up();
        boolean left();
        boolean right();
}


