package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import entity.Controls;

public class KeyHandlerArrows implements KeyListener, Controls {

    public boolean upPressed, leftPressed, rightPressed, shotKeyPressed;

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_UP) {
            upPressed = true;
        }


        if (code == KeyEvent.VK_LEFT) {
            leftPressed = true;
        }

        if (code == KeyEvent.VK_RIGHT) {
            rightPressed = true;
        }

        if (code == KeyEvent.VK_CONTROL) {
            shotKeyPressed = true;
        }
    }
    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_UP) {
            upPressed = false;
        }

        if (code == KeyEvent.VK_LEFT) {
            leftPressed = false;
        }

        if (code == KeyEvent.VK_RIGHT) {
            rightPressed = false;
        }

        if (code == KeyEvent.VK_CONTROL) {
            shotKeyPressed = false;
        }

    }

    @Override
    public boolean up(){
        return upPressed;
    }

    @Override
    public boolean left(){
        return leftPressed;
    }

    @Override
    public boolean right (){ return rightPressed; }

    @Override
    public boolean shot (){
        return shotKeyPressed;
    }

}