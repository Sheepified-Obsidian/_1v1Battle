package object;
import entity.Projectile;
import main.GamePanel;
public class OBJ_Projectile extends Projectile{

    GamePanel gp;

    public OBJ_Projectile(GamePanel gp) {
        super(gp);
        this.gp = gp;

        int projSpeed = 5;
        int damage = 1;

    }

    public void getImage() {

    }
}
