package entity;
import main.GamePanel;

import java.awt.image.BufferedImage;

public class Projectile {
        BufferedImage rightlooking, leftlooking;
        String direction = "right";
        int projX;
        int projY;

        double velocityX = 0;
        GamePanel gp;
        public Projectile projectile;

        public Projectile (GamePanel gp) {
              this.gp = gp;
        }

        public void set() {

        }

        public void update() {

        }

}
