package object;

import java.io.IOException;
import javax.imageio.ImageIO;

public class OBJ_Healthbar extends SuperObject {
    public OBJ_Healthbar(){
        name = "Healthbar";
        try{
        image = ImageIO.read(getClass().getResourceAsStream("sprites/hearts/Health Bar.png"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
