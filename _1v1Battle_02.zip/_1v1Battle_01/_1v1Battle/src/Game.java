import javax.swing.*;

public class Game  {
    public static void main(String[] args) {
        JFrame window = new JFrame();
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);
        window.setTitle("");
        window.setLocationRelativeTo(null);
        window.setVisible(true);
        window.setSize(1500,1000);
    }
}
