import javax.swing.*;

public class GamePanel extends JPanel {
    final int originalTitleSize = 16;
    final int scale = 3;



}
