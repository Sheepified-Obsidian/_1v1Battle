import java.io.IOException;
import javax.imageio.ImageIO;

public class PlatformManager {
    Platform[] platform;

    public PlatformManager(GamePanel gamepanel) {
           platform = new Platform(10);
    }

    public void getPlatformImage()  {

        try {
            platform[0] = new Platform();
            platform[0].image = ImageIO.read(getClass().getResourceAsStream("/block/block_improv.png"));
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }
}
