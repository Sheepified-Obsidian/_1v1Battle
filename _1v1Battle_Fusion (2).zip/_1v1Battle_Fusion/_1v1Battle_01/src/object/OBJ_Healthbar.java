package object;

public class OBJ_Healthbar {
}
