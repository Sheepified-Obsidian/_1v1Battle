package main;
import javax.swing.*;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

public class Game extends JFrame {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame window = new JFrame();
            window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            window.setResizable(false);
            window.setUndecorated(false);
            window.setTitle("Lokales Kombat Multiplayer Spiel");

            GamePanel gamePanel = new GamePanel();
            gamePanel.setupGame();
            window.add(gamePanel);
            window.pack();
            window.setLocationRelativeTo(null);
            window.setVisible(true);

            GraphicsDevice device =
                    GraphicsEnvironment
                            .getLocalGraphicsEnvironment()
                            .getDefaultScreenDevice();
            window.setExtendedState(JFrame.MAXIMIZED_BOTH);

            gamePanel.requestFocusInWindow();
            gamePanel.startGameThread();
        });
    }
}
