import javax.swing.*;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicTreeUI;
import java.awt.*;


public class GamePanel extends JPanel implements Runnable {
    final int originalTileSize = 16;
    final int scale = 3;
    public final int tileSize = originalTileSize * scale;
    final int maxScreenCol = 16;
    final int maxScreenRow = 12;
    final int screenWidth = tileSize * maxScreenCol;
    final int screenHeight = tileSize * maxScreenRow;
    KeyHandlerWASD keyHWASD = new KeyHandlerWASD();
    KeyHandlerArrows keyHArrows = new KeyHandlerArrows();
    Player p1 = new Player(this, keyHWASD);
    Player p2 = new Player(this, keyHArrows);

    Thread gameThread;

    public GamePanel() {
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
        this.setFocusable(true);
        this.addKeyListener(keyHArrows);
        this.addKeyListener(keyHWASD);
    }

    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {
        while (gameThread != null) {
            update();
            repaint();

            try {
                Thread.sleep(16);  //Millisekunden
            } catch(Exception e) {
                e.printStackTrace();
            } // end of try
        }
    }

    public void update() {
        p1.update();
        p2.update();
    }

    @Override
    public void paintComponent (Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        p1.draw(g2);
        p2.draw(g2);
        g2.dispose();
    }
}

