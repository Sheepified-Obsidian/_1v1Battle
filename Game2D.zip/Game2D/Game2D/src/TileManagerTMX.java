import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class TileManagerTMX {

    public final int tileSize = 32;

    private Tile[] tiles;
    private int[][] mapTileNum;

    private int maxCol;
    private int maxRow;

    GameScreen gp;

    // =============================

    public TileManagerTMX(GameScreen gp) {
        this.gp = gp;

        loadTileset("/tiles/tiles_grass2.png");
        loadTMX("/maps/map.tmx");
    }

    // =============================
    // 1️⃣ TILESET LADEN
    // =============================

    private void loadTileset(String path) {
        try {
            BufferedImage tileset =
                    ImageIO.read(getClass().getResourceAsStream(path));

            int tilesPerRow = tileset.getWidth() / tileSize;
            int tilesPerCol = tileset.getHeight() / tileSize;

            tiles = new Tile[tilesPerRow * tilesPerCol];

            for (int i = 0; i < tiles.length; i++) {

                tiles[i] = new Tile();

                int x = (i % tilesPerRow) * tileSize;
                int y = (i / tilesPerRow) * tileSize;

                tiles[i].image =
                        tileset.getSubimage(x, y, tileSize, tileSize);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // =============================
    // 2️⃣ TMX LADEN
    // =============================

    private void loadTMX(String path) {
        try {
            InputStream is = getClass().getResourceAsStream(path);

            DocumentBuilder builder =
                    DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = builder.parse(is);

            Element map = doc.getDocumentElement();

            maxCol = Integer.parseInt(map.getAttribute("width"));
            maxRow = Integer.parseInt(map.getAttribute("height"));

            mapTileNum = new int[maxCol][maxRow];

            NodeList layers = map.getElementsByTagName("layer");
            Element layer = (Element) layers.item(0); // erster Layer

            Element data =
                    (Element) layer.getElementsByTagName("data").item(0);

            String[] tileIDs =
                    data.getTextContent().trim().split(",");

            int index = 0;

            for (int row = 0; row < maxRow; row++) {
                for (int col = 0; col < maxCol; col++) {

                    int id = Integer.parseInt(tileIDs[index].trim());

                    // Tiled beginnt bei 1, Array bei 0
                    mapTileNum[col][row] = id - 1;

                    index++;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // =============================
    // 3️⃣ ZEICHNEN
    // =============================

    public void draw(Graphics g) {

        for (int row = 0; row < maxRow; row++) {
            for (int col = 0; col < maxCol; col++) {

                int tileNum = mapTileNum[col][row];

                if (tileNum < 0) continue; // leeres Tile

                int x = col * tileSize;
                int y = row * tileSize;

                g.drawImage(
                        tiles[tileNum].image,
                        x, y,
                        tileSize, tileSize,
                        null
                );
            }
        }
    }
}
