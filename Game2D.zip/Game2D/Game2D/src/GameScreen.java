import javax.swing.*;
import java.awt.*;

public class GameScreen extends JPanel implements Runnable{

    private KeyHandler keyH = new KeyHandler();  //neues KeyHandler Objekt erzeugen
    private Thread gameThread;
    private Player player;
    TileManagerMultiLayer tileM;

    public GameScreen(){

        this.setPreferredSize(new Dimension(640,640));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
        this.addKeyListener(keyH);       //KeyHandler dem Panel zuweisen
        this.setFocusable(true);        //den Focus auf dieses Panel setzen
        tileM = new TileManagerMultiLayer(this);
        player = new Player(keyH);

    }

    public void startGameThread(){
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run() {
        while(gameThread != null) {
            // in diesem loop werden wir folgendes tun:
            // 1. UPDATE: Informationen, sowas wie Position etc.
            // 2. ZEICHNEN: den Bildschirm neu zeichnen mit den neien Positionen der Charaktere
            update();
            repaint();  //damit ruft man die paintComponent Methode auf

            try {
                Thread.sleep(16);  //Millisekunden
            } catch(Exception e) {
                e.printStackTrace();
            } // end of try
        }
    }


    public void update(){
        player.update();
    }


    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);    //das ist so festgelegt, wenn man die paintComponent nutzt, dann nutzt man auch die Super-Klasse
                                    //das super bedeutet, dass es die Elternklasse der JPanel-Klasse
        tileM.draw(g);
        player.draw(g);
    }
}
