import java.awt.image.BufferedImage;

public class Entity {
     protected int x, y;
     protected int speed;

     public BufferedImage up, down;
     public String direction;


}

