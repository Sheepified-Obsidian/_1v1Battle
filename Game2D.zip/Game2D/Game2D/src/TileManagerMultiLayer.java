
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;

public class TileManagerMultiLayer {

    public final int tileSize = 32;

    private Tile[] tiles;
    private int[][][] mapTileNum;

    private int maxCol;
    private int maxRow;
    private int layerCount;

    GameScreen gp;

    // =============================

    public TileManagerMultiLayer(GameScreen gp) {
        this.gp = gp;

        loadTileset("/tiles/tiles_grass2.png");
        loadTMX("/maps/map2.tmx");
    }

    // =============================
    // 1️⃣ TILESET LADEN
    // =============================

    private void loadTileset(String path) {
        try {
            BufferedImage tileset =
                    ImageIO.read(getClass().getResourceAsStream(path));

            int tilesPerRow = tileset.getWidth() / tileSize;
            int tilesPerCol = tileset.getHeight() / tileSize;

            tiles = new Tile[tilesPerRow * tilesPerCol];

            for (int i = 0; i < tiles.length; i++) {

                tiles[i] = new Tile();

                int x = (i % tilesPerRow) * tileSize;
                int y = (i / tilesPerRow) * tileSize;

                tiles[i].image =
                        tileset.getSubimage(x, y, tileSize, tileSize);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // =============================
    // 2️⃣ TMX MIT MEHREREN LAYERN
    // =============================

    private void loadTMX(String path) {
        try {
            InputStream is = getClass().getResourceAsStream(path);

            DocumentBuilder builder =
                    DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = builder.parse(is);

            Element map = doc.getDocumentElement();

            maxCol = Integer.parseInt(map.getAttribute("width"));
            maxRow = Integer.parseInt(map.getAttribute("height"));

            NodeList layers = map.getElementsByTagName("layer");
            layerCount = layers.getLength();

            mapTileNum = new int[layerCount][maxCol][maxRow];

            // Alle Layer einlesen
            for (int l = 0; l < layerCount; l++) {

                Element layer = (Element) layers.item(l);
                Element data =
                        (Element) layer.getElementsByTagName("data").item(0);

                String[] tileIDs =
                        data.getTextContent().trim().split(",");

                int index = 0;

                for (int row = 0; row < maxRow; row++) {
                    for (int col = 0; col < maxCol; col++) {

                        int id = Integer.parseInt(tileIDs[index].trim());

                        // Tiled: 0 = leer, sonst ab 1
                        mapTileNum[l][col][row] = id - 1;

                        index++;
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // =============================
    // 3️⃣ ZEICHNEN (Layer für Layer)
    // =============================

    public void draw(Graphics g) {

        // Layer-Reihenfolge ist entscheidend!
        for (int l = 0; l < layerCount; l++) {
            for (int row = 0; row < maxRow; row++) {
                for (int col = 0; col < maxCol; col++) {

                    int tileNum = mapTileNum[l][col][row];
                    if (tileNum < 0) continue;

                    int x = col * tileSize;
                    int y = row * tileSize;

                    g.drawImage(
                            tiles[tileNum].image,
                            x, y,
                            tileSize, tileSize,
                            null
                    );
                }
            }
        }
    }
}
