import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class TileManagerE {

    public final int tileSize = 32;
    public final int maxCol = 20;
    public final int maxRow = 20;

    private Tile tile;          // NUR EIN TILE
    private int selectedTile;   // bewusst gewählter Index
    GameScreen gp;

    public TileManagerE(GameScreen gp) {
        this.gp = gp;
        selectedTile = 9;
        loadSingleTile();
    }

    // =============================

    private void loadSingleTile() {
        try {
            BufferedImage tileset =
                    ImageIO.read(getClass().getResourceAsStream("/tiles/tiles_grass2.png"));
            System.out.println(tileset.getWidth());
            int tilesPerRow = tileset.getWidth() / tileSize;

            tile = new Tile();

            int x = (selectedTile % tilesPerRow) * tileSize;
            int y = (selectedTile / tilesPerRow) * tileSize;

            tile.image = tileset.getSubimage(x, y, tileSize, tileSize);

            // optional: Kollision bewusst setzen
            tile.collision = false;

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // =============================

    public void draw(Graphics g) {
        for (int row = 0; row < maxRow; row++) {
            for (int col = 0; col < maxCol; col++) {

                int x = col * tileSize;
                int y = row * tileSize;

                g.drawImage(
                        tile.image,
                        x, y,
                        tileSize, tileSize,
                        null
                );
            }
        }
    }
}

