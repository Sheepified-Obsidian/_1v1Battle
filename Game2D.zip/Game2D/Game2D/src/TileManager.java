import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;

public class TileManager {

    GameScreen gp;

    public Tile[] tiles;
    public int[][] mapTileNum;

    public final int tileSize = 32;
    public final int maxCol = 20;
    public final int maxRow = 20;

    public TileManager(GameScreen gp) {
        this.gp = gp;

        tiles = new Tile[60];
        mapTileNum = new int[maxCol][maxRow];


        loadTileset();                 // 1️⃣ Tiles laden
        loadMap("/maps/map.txt");    // 2️⃣ Map laden
    }

    // Tileset laden

    private void loadTileset() {
        try {
            BufferedImage tileset =
                    ImageIO.read(getClass().getResourceAsStream("/tiles/tiles_grass2.png"));

            int tilesPerRow = tileset.getWidth() / tileSize;

            for (int i = 0; i < tiles.length; i++) {

                tiles[i] = new Tile();

                int x = (i % tilesPerRow) * tileSize;
                int y = (i / tilesPerRow) * tileSize;

                if (y + tileSize <= tileset.getHeight()) {
                    tiles[i].image =
                            tileset.getSubimage(x, y, tileSize, tileSize);
                }
            }

            // Beispiel-Kollision
            tiles[0].collision = true;

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // Map laden

    private void loadMap(String path) {
        try {
            InputStream is = getClass().getResourceAsStream(path);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            int row = 0;
            String line;

            while ((line = br.readLine()) != null && row < maxRow) {

                String[] numbers = line.split(",");

                for (int col = 0; col < numbers.length && col < maxCol; col++) {
                    // -1 weil Map bei 1 beginnt, Array bei 0
                    mapTileNum[col][row] =
                            Integer.parseInt(numbers[col].trim()) - 1;
                }
                row++;
            }
            br.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // =============================
    // SCHRITT 3: Map zeichnen
    // =============================

    public void draw(Graphics g) {

        for (int row = 0; row < maxRow; row++) {
            for (int col = 0; col < maxCol; col++) {

                int tileNum = mapTileNum[col][row];

                int x = col * tileSize;
                int y = row * tileSize;

                g.drawImage(
                        tiles[tileNum].image,
                        x, y,
                        tileSize, tileSize,
                        null
                );
            }
        }
    }
}
