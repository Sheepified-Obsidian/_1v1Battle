import javax.swing.*;


public class Game extends JFrame {

    public Game(){
        setSize(640,640);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setTitle("Game");
        setResizable(false);

        GameScreen gameScreen = new GameScreen();
        add(gameScreen);

        gameScreen.startGameThread();

        setVisible(true);
    }

    public static void main(String[] args) {

        Game game = new Game();
    }
}
