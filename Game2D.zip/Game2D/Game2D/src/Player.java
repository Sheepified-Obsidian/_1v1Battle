import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Player extends Entity{

    private KeyHandler keyH;

    public Player(KeyHandler keyH) {
        this.keyH = keyH;
        x = 100;
        y = 100;
        speed = 4;
        direction = "down";

        getPlayerImage();
    }

    public void getPlayerImage(){
        try {

             up = ImageIO.read(getClass().getResourceAsStream("/player/FigurUp.png"));
            down = ImageIO.read(getClass().getResourceAsStream("/player/FigurDown.png"));

        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void update() {
        if (keyH.upPressed == true){             //kürzer : if (keyH.upPressed)  y -= speed;
            direction = "up";
            y -= speed;
        }
        if (keyH.downPressed == true){
            direction = "down";
            y += speed;
        }
        if (keyH.leftPressed == true){
            direction = "down";
            x -= speed;
        }
        if (keyH.rightPressed == true){
            direction = "down";
            x += speed;
        }
    }

    public void draw(Graphics g) {
        //g.fillRect(x, y, 50, 50);

        BufferedImage image = null;

        if (direction == "up") {
            image = up;
        }
        if (direction == "down") {
            image = down;
        }

        g.drawImage(image, x,y,50,50, null);



    }
}
