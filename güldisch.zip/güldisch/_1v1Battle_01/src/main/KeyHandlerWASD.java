package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import entity.Controls;

public class KeyHandlerWASD implements KeyListener, Controls {

    public boolean upPressed, leftPressed, rightPressed, shotKeyPressed;


    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();

        if (code == KeyEvent.VK_W) {
            upPressed = true;
        }

        if (code == KeyEvent.VK_A) {
            leftPressed = true;
        }

        if (code == KeyEvent.VK_D) {
            rightPressed = true;
        }

        if (code == KeyEvent.VK_SPACE) {
            shotKeyPressed = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

        int code = e.getKeyCode();

        if (code == KeyEvent.VK_W) {
            upPressed = false;
        }

        if (code == KeyEvent.VK_A) {
            leftPressed = false;
        }

        if (code == KeyEvent.VK_D) {
            rightPressed = false;
        }

        if (code == KeyEvent.VK_SPACE) {
            shotKeyPressed = false;
        }
    }

    @Override
    public boolean up(){
        return upPressed;
    }

    @Override
    public boolean left(){
        return leftPressed;
    }

    @Override
    public boolean right (){
        return rightPressed;
    }

    @Override
    public boolean shot (){
        return shotKeyPressed;
    }

}
