package object;
import entity.Projectile;
import main.GamePanel;
import platform.Platform;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Objects;

public class OBJ_Projectile extends Projectile{

    GamePanel gp;
    BufferedImage rightlooking, leftlooking;

    public OBJ_Projectile(GamePanel gp) {
        super(gp);
        this.gp = gp;


        getImage();
    }

    /*public void getImage() {
        try {
            rightlooking = ImageIO.read(getClass().getResourceAsStream("/sprites/block/waer.png"));
            leftlooking = ImageIO.read(getClass().getResourceAsStream("/sprites/block/waer.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

     */
}
