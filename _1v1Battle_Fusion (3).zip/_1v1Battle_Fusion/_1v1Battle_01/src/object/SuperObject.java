package object;

import main.GamePanel;

import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
public class SuperObject {
    public BufferedImage image;
    public String name;
    public boolean collision = false;
    public int worldX, worldY;
    //public void draw(Graphics2D g2, GamePanel gp);


}
