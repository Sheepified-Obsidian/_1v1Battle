package platform;

import main.GamePanel;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.Graphics2D;




public class PlatformManager {
    Platform[] platform;
    GamePanel gp;
    public PlatformManager(GamePanel gp) {

        this.gp = gp;

        platform = new Platform[10];

        getPlatformImage();

    }

    public void getPlatformImage() {

        try {
            platform[0] = new Platform();
            platform[0].image = ImageIO.read(getClass().getResourceAsStream("/block/block_improv.png"));

            //platform[0] = new platform.Platform();
            //platform[0].image = ImageIO.read(getClass().getResourceAsStream("/block/block_improv.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void draw(Graphics2D g2) {

            g2.drawImage(platform[0].image, 0, 0, gp.tileSize, gp.tileSize, null);

            int col = 0;
            int row = 0;
            int x = 0;
            int y = 0;

            while(col < gp.maxScreenCol && row < gp.maxScreenRow) {

                g2.drawImage(platform[0].image, x, y, gp.tileSize, gp.tileSize, null);
                col++;
                x += gp.tileSize;

                if(col == gp.maxScreenCol) {
                    col = 0;
                    x = 0;
                    row++;
                    y += gp.tileSize;
                }
            }
        }
    }

