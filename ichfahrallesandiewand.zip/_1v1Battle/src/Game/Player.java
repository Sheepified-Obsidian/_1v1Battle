package Game;

import java.awt.*;
import java.security.Key;

public class Player {
 int playerX;
 int playerY;
 int playerSpeed;
 GamePanel gamepanel;
 Controls controls;

 public Player(GamePanel gamepanel, Controls controls){ //Constructor
     this.gamepanel = gamepanel;
     this.controls = controls;
     setDefaultValues();
 }

 public void setDefaultValues(){
     playerX =  100;
     playerY = 100;
     playerSpeed = 4;
 }

public void update(){
    if (controls.up() == true) {
        playerY -= playerSpeed;
    } else if (controls.down() == true) {
        playerY += playerSpeed;
    } else if (controls.left() == true) {
        playerX -= playerSpeed;
    } else if (controls.right() == true) {
        playerX += playerSpeed;
    }
}

public void draw(Graphics2D g2){
    g2.setColor(Color.white);
    g2.fillRect(playerX, playerY, gamepanel.tileSize, gamepanel.tileSize);
}
}
